# 2nd-start
2기 GitHub PR 실습

## 가이드

> [문서 참고](https://hg-edu.notion.site/GitHub-Pull-Request-fdea6eb3d7054b36ae8ee2888b6e1f9b)

1. 해당 프로젝트를 Fork 한다.

2. Clone 한다. **Clone시 URL 반드시 확인 부탁드립니다.**

3. `5회차_홍길동.md` 으로 파일을 만들고 내용을 작성한다. (브랜치는 master에서 해도 상관 없음)

    * 후기, 다짐 등 자유롭게 작성 가능 
    * 아무 내용 없어도 됩니다. 
    
4. 커밋한 이후에 push 하시고, GitHub에서 Pull Request를 생성해주세요. 

